<?php
namespace local_rubricai;

defined('MOODLE_INTERNAL') || die();

/**
 * Class to extract course data for RubricAI
 */
class data_provider {
 
    /** Allowed file extensions for RAG processing */
    private const ALLOWED_EXTS = ['pdf', 'ppt', 'pptx', 'docx', 'doc', 'txt'];

    /** Allowed module types for building the library */
    private const RESOURCE_MODULES = ['resource', 'folder', 'page', 'url', 'book', 'label', 'imscp', 'assign', 'forum', 'quiz'];

    /**
     * Get a summary of the course content
     * 
     * @param int $courseid
     * @return array
     */
    public static function get_course_summary($courseid) {
        global $DB;

        $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $modinfo = get_fast_modinfo($course);
        
        $data = [
            'fullname' => $course->fullname,
            'shortname' => $course->shortname,
            'summary' => self::clean_html($course->summary),
            'sections' => []
        ];

        foreach ($modinfo->get_section_info_all() as $section) {
            if ($section->uservisible && ($section->summary || !empty($modinfo->sections[$section->section]))) {
                $sectiondata = [
                    'name' => self::get_section_name_clean($course, $section),
                    'summary' => self::clean_html($section->summary),
                    'activities' => []
                ];

                if (!empty($modinfo->sections[$section->section])) {
                    foreach ($modinfo->sections[$section->section] as $cmid) {
                        $cm = $modinfo->get_cm($cmid);
                        if ($cm->uservisible) {
                            $sectiondata['activities'][] = [
                                'name' => $cm->name,
                                'type' => $cm->modname,
                                'description' => self::clean_html($cm->content) // Simplificado
                            ];
                        }
                    }
                }
                $data['sections'][] = $sectiondata;
            }
        }

        return $data;
    }

    /**
     * Get all files associated with the course
     * 
     * @param int $courseid
     * @return array
     */
    public static function get_course_files($courseid, $extract_to_sync_dir = false) {
        global $CFG, $DB;
        $fs = get_file_storage();
        $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $modinfo = get_fast_modinfo($course);
        $res = [];
        
        $base_sync_dir = '';
        if ($extract_to_sync_dir) {
            self::delete_sync_dir($courseid);
            $base_sync_dir = $CFG->dataroot . '/rubricai_sync/course_' . $courseid;
            if (!file_exists($base_sync_dir)) {
                mkdir($base_sync_dir, 0777, true);
            }
        }

        // 1. Files in the course context itself (Intro, general files)
        $course_context = \context_course::instance($courseid);
        $course_files = $fs->get_area_files($course_context->id, 'course', 'section');
        foreach ($course_files as $file) {
            if (!$file->is_directory()) {
                $ext = strtolower(pathinfo($file->get_filename(), PATHINFO_EXTENSION));
                if (!in_array($ext, self::ALLOWED_EXTS)) {
                    continue;
                }
                
                $section_folder = $base_sync_dir . '/0_General';
                $reldata = [
                    'filename' => $file->get_filename(),
                    'mimetype' => $file->get_mimetype(),
                    'size' => $file->get_filesize(),
                    'section' => 'General'
                ];
                if ($extract_to_sync_dir) {
                    if (!file_exists($section_folder)) mkdir($section_folder, 0777, true);
                    $localpath = $section_folder . '/' . $file->get_filename();
                    if (file_exists($localpath)) $localpath = $section_folder . '/' . $file->get_contenthash() . '_' . $file->get_filename();
                    if (!file_exists($localpath)) $file->copy_content_to($localpath);
                    $reldata['localpath'] = $localpath;
                }
                $res[] = $reldata;
            }
        }

        // 2. Traverse sections and modules
        foreach ($modinfo->get_section_info_all() as $section) {
            $section_name = clean_param(self::get_section_name_clean($course, $section), PARAM_FILE);
            $section_folder_name = $section->section . '_' . ($section_name ?: 'Section');
            
                foreach ($modinfo->sections[$section->section] as $cmid) {
                    $cm = $modinfo->get_cm($cmid);
                    if (!$cm->uservisible) continue;
                    if (!in_array($cm->modname, self::RESOURCE_MODULES)) continue;

                    $activity_name = clean_param($cm->name, PARAM_FILE);
                    $activity_folder_name = $cm->id . '_' . ($activity_name ?: 'Activity');

                    // A. Export virtual text file representing activity instructions/questions
                    $activity_text = self::get_activity_text($cm);
                    if (!empty($activity_text)) {
                        $v_filename = clean_param($cm->name, PARAM_FILE);
                        $v_filename = trim($v_filename, ' .-_');
                        if (empty($v_filename)) {
                            $v_filename = 'actividad_' . $cm->id;
                        }
                        $v_filename .= '.txt';

                        $reldata = [
                            'filename' => $v_filename,
                            'mimetype' => 'text/plain',
                            'size'     => strlen($activity_text),
                            'section'  => $section_name,
                            'module'   => $cm->name,
                            'modname'  => $cm->modname
                        ];

                        if ($extract_to_sync_dir) {
                            $target_dir = $base_sync_dir . '/' . $section_folder_name . '/' . $activity_folder_name;
                            if (!file_exists($target_dir)) {
                                mkdir($target_dir, 0777, true);
                            }
                            $localpath = $target_dir . '/' . $v_filename;
                            try {
                                file_put_contents($localpath, $activity_text);
                            } catch (\Exception $e) {
                                file_put_contents($CFG->dataroot . '/rubricai_sync/debug.txt', "Error writing virtual file for " . $cm->name . ": " . $e->getMessage() . "\n", FILE_APPEND);
                            }
                            $reldata['localpath'] = $localpath;
                        }
                        $res[] = $reldata;
                    }

                    // B. Export actual physical files in this module's context
                    $mod_context = \context_module::instance($cm->id);
                    
                    // Fetch all files associated with this module's context, regardless of component/filearea
                    $module_files = [];
                    $filerecords = $DB->get_records('files', ['contextid' => $mod_context->id]);
                    foreach ($filerecords as $r) {
                        if ($r->filename !== '.') {
                            try {
                                $module_files[] = $fs->get_file_instance($r);
                            } catch (\Exception $e) {
                                // Ignore missing file data
                            }
                        }
                    }
                    
                    foreach ($module_files as $file) {
                        if ($file->is_directory()) continue;
                        // Avoid system/temp files
                        if ($file->get_component() == 'user' || $file->get_filearea() == 'draft') continue;
                        // Only allow teacher/module files, avoid student submissions or feedback files
                        if (strpos($file->get_component(), 'mod_') !== 0) continue;

                        $ext = strtolower(pathinfo($file->get_filename(), PATHINFO_EXTENSION));
                        if (!in_array($ext, self::ALLOWED_EXTS)) {
                            continue;
                        }

                        $reldata = [
                            'filename' => $file->get_filename(),
                            'mimetype' => $file->get_mimetype(),
                            'size' => $file->get_filesize(),
                            'section' => $section_name,
                            'module' => $cm->name,
                            'modname' => $cm->modname
                        ];

                        if ($extract_to_sync_dir) {
                            $target_dir = $base_sync_dir . '/' . $section_folder_name . '/' . $activity_folder_name;
                            if (!file_exists($target_dir)) {
                                mkdir($target_dir, 0777, true);
                            }
                            $localpath = $target_dir . '/' . $file->get_filename();
                            if (file_exists($localpath)) {
                                $localpath = $target_dir . '/' . $file->get_contenthash() . '_' . $file->get_filename();
                            }
                            if (!file_exists($localpath)) {
                                try {
                                    $file->copy_content_to($localpath);
                                } catch (\Exception $e) {
                                    file_put_contents($CFG->dataroot . '/rubricai_sync/debug.txt', "Error copying " . $file->get_filename() . ": " . $e->getMessage() . "\n", FILE_APPEND);
                                }
                            }
                            $reldata['localpath'] = $localpath;
                        }
                        $res[] = $reldata;
                    }
                }
        }
        
        return $res;
    }

    /**
     * Get a hierarchical tree of course materials (Course > Sections > Activities > Files).
     *
     * @param int $courseid
     * @return array
     */
    public static function get_course_materials_tree(int $courseid): array {
        global $DB;
        $fs = get_file_storage();
        $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $modinfo = get_fast_modinfo($course);

        $tree = [
            'id'       => $courseid,
            'name'     => $course->fullname,
            'type'     => 'course',
            'sections' => []
        ];

        // 1. Files in the course context itself (Intro / General files)
        $course_context = \context_course::instance($courseid);
        $course_files = $fs->get_area_files($course_context->id, 'course', 'section');
        $general_files = [];
        foreach ($course_files as $file) {
            if ($file->is_directory()) continue;
            $ext = strtolower(pathinfo($file->get_filename(), PATHINFO_EXTENSION));
            if (!in_array($ext, self::ALLOWED_EXTS)) continue;

            $general_files[] = [
                'id'       => $file->get_id(),
                'name'     => $file->get_filename(),
                'type'     => 'file',
                'relpath'  => '0_General/' . $file->get_filename()
            ];
        }

        if (!empty($general_files)) {
            $tree['sections'][] = [
                'id'         => 0,
                'name'       => 'Materiales generales del curso',
                'type'       => 'section',
                'activities' => [
                    [
                        'id'    => 'gen',
                        'name'  => 'Archivos intro',
                        'type'  => 'activity',
                        'files' => $general_files
                    ]
                ]
            ];
        }

        // 2. Traverse sections and activities
        foreach ($modinfo->get_section_info_all() as $section) {
            if (!$section->uservisible) continue;
            if (empty($modinfo->sections[$section->section])) continue;

            $section_name_raw = self::get_section_name_clean($course, $section);
            $section_name_clean = clean_param($section_name_raw, PARAM_FILE);
            $section_folder_name = $section->section . '_' . ($section_name_clean ?: 'Section');

            $section_node = [
                'id'         => $section->id,
                'name'       => $section_name_raw,
                'type'       => 'section',
                'activities' => []
            ];

            foreach ($modinfo->sections[$section->section] as $cmid) {
                $cm = $modinfo->get_cm($cmid);
                if (!$cm->uservisible) continue;
                if (!in_array($cm->modname, self::RESOURCE_MODULES)) continue;

                $activity_name_clean = clean_param($cm->name, PARAM_FILE);
                $activity_folder_name = $cm->id . '_' . ($activity_name_clean ?: 'Activity');

                $activity_node = [
                    'id'    => $cm->id,
                    'name'  => $cm->name,
                    'type'  => 'activity',
                    'files' => []
                ];

                // Generate virtual file node representing the activity's details/description
                $activity_text = self::get_activity_text($cm);
                if (!empty($activity_text)) {
                    $v_filename = clean_param($cm->name, PARAM_FILE);
                    $v_filename = trim($v_filename, ' .-_');
                    if (empty($v_filename)) {
                        $v_filename = 'actividad_' . $cm->id;
                    }
                    $v_filename .= '.txt';

                    $activity_node['files'][] = [
                        'id'      => 'virtual_' . $cm->id,
                        'name'    => $v_filename,
                        'type'    => 'file',
                        'relpath' => $section_folder_name . '/' . $activity_folder_name . '/' . $v_filename
                    ];
                }

                // Use DB to get all files in this module's context, regardless of filearea
                try {
                    $mod_context = \context_module::instance($cm->id);
                    $filerecords = $DB->get_records('files', ['contextid' => $mod_context->id]);
                    
                    foreach ($filerecords as $r) {
                        try {
                            $file = $fs->get_file_instance($r);
                        } catch (\Exception $e) {
                            continue;
                        }

                        if ($file->is_directory()) continue;
                        if ($file->get_component() === 'user' || $file->get_filearea() === 'draft') continue;
                        // Only allow teacher/module files, avoid student submissions or feedback files
                        if (strpos($file->get_component(), 'mod_') !== 0) continue;

                        $ext = strtolower(pathinfo($file->get_filename(), PATHINFO_EXTENSION));
                        if (!in_array($ext, self::ALLOWED_EXTS)) continue;

                        $activity_node['files'][] = [
                            'id'      => $file->get_id(),
                            'name'    => $file->get_filename(),
                            'type'    => 'file',
                            'relpath' => $section_folder_name . '/' . $activity_folder_name . '/' . $file->get_filename()
                        ];
                    }
                } catch (\Exception $e) {
                    continue; // Skip activities with context errors
                }

                if (!empty($activity_node['files'])) {
                    $section_node['activities'][] = $activity_node;
                }
            }

            if (!empty($section_node['activities'])) {
                $tree['sections'][] = $section_node;
            }
        }

        return $tree;
    }

    /**
     * Return the list of visible course sections for the quiz injection selector.
     *
     * @param int $courseid
     * @return array  [['num' => int, 'name' => string], ...]
     */
    public static function get_course_sections(int $courseid): array {
        global $DB;
        $course   = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $modinfo  = get_fast_modinfo($course);
        $sections = [];
        foreach ($modinfo->get_section_info_all() as $section) {
            if (!$section->uservisible) continue;
            $sections[] = [
                'num'  => (int)$section->section,
                'name' => self::get_section_name_clean($course, $section),
            ];
        }
        return $sections;
    }

    /**
     * Programmatically create a Moodle Quiz with the given questions.
     * Compatible with both Moodle 3.x and Moodle 4.x question bank structures.
     *
     * @param int    $courseid
     * @param int    $section_num  Section number (0 = section 0 / General)
     * @param array  $questions    Array of question data from step7::get_fake_questions()
     * @param string $name         Quiz activity name
     * @return array  ['coursemodule' => int]
     */
    public static function create_quiz_activity(
        int $courseid,
        int $section_num,
        array $questions,
        string $name = 'Cuestionario RubricAI',
        ?float $max_grade = null
    ): array {
        global $CFG, $DB, $USER;
        require_once($CFG->dirroot . '/course/lib.php');
        require_once($CFG->libdir  . '/questionlib.php');
        require_once($CFG->dirroot . '/mod/quiz/lib.php');
        require_once($CFG->dirroot . '/mod/quiz/locallib.php');

        $course         = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $module         = $DB->get_record('modules', ['name' => 'quiz'], '*', MUST_EXIST);
        $course_context = \context_course::instance($courseid);

        // ----------------------------------------------------------------
        // 1. Create the quiz instance record
        // ----------------------------------------------------------------
        $quiz = new \stdClass();
        $quiz->course              = $courseid;
        $quiz->name                = $name;
        $quiz->intro               = '';
        $quiz->introformat         = FORMAT_HTML;
        $quiz->timeopen            = 0;
        $quiz->timeclose           = 0;
        $quiz->timelimit           = 0;
        $quiz->overduehandling     = 'autosubmit';
        $quiz->graceperiod         = 0;
        $quiz->preferredbehaviour  = 'deferredfeedback';
        $quiz->canredoquestions    = 0;
        $quiz->attempts            = 0;
        $quiz->attemptonlast       = 0;
        $quiz->grademethod         = 1; // QUIZ_GRADEHIGHEST
        $quiz->decimalpoints       = 2;
        $quiz->questiondecimalpoints = -1;
        $quiz->reviewattempt       = 69904;
        $quiz->reviewcorrectness   = 4368;
        $quiz->reviewmarks         = 4368;
        $quiz->reviewspecificfeedback = 4368;
        $quiz->reviewgeneralfeedback  = 4368;
        $quiz->reviewrightanswer   = 4368;
        $quiz->reviewoverallfeedback  = 4368;
        $quiz->questionsperpage    = 0;
        $quiz->navmethod           = 'free';
        $quiz->shuffleanswers      = 1;
        $quiz->sumgrades           = 0;
        $quiz->grade               = $max_grade !== null ? $max_grade : count($questions) * 1.0;
        $quiz->timecreated         = time();
        $quiz->timemodified        = time();
        $quiz->password            = '';
        $quiz->subnet              = '';
        $quiz->browsersecurity     = '-';
        $quiz->delay1              = 0;
        $quiz->delay2              = 0;
        $quiz->showuserpicture     = 0;
        $quiz->showblocks          = 0;
        $quiz->id = $DB->insert_record('quiz', $quiz);

        // ----------------------------------------------------------------
        // 2. Attach quiz to a course section
        // ----------------------------------------------------------------
        $modinfo    = get_fast_modinfo($course);
        $section_id = 0;
        foreach ($modinfo->get_section_info_all() as $s) {
            if ((int)$s->section === $section_num) {
                $section_id = $s->id;
                break;
            }
        }
        // Fallback: use first non-zero section, or 0
        if (!$section_id) {
            foreach ($modinfo->get_section_info_all() as $s) {
                if ($s->section > 0) {
                    $section_id  = $s->id;
                    $section_num = $s->section;
                    break;
                }
            }
        }
        if (!$section_id) {
            foreach ($modinfo->get_section_info_all() as $s) {
                if ((int)$s->section === 0) {
                    $section_id  = $s->id;
                    $section_num = $s->section;
                    break;
                }
            }
        }

        $cm           = new \stdClass();
        $cm->course   = $courseid;
        $cm->module   = $module->id;
        $cm->instance = $quiz->id;
        $cm->section  = $section_id;
        $cm->id       = add_course_module($cm);
        course_add_cm_to_section($courseid, $cm->id, $section_num);

        // ----------------------------------------------------------------
        // CRITICAL: Set cmid on the quiz object NOW, before adding questions.
        // quiz_add_quiz_question() in Moodle 4.x needs quiz->cmid to create
        // the question_references record. Without it, it falls back to
        // get_coursemodule_from_instance() which can fail silently on a
        // freshly-inserted CM (cache not warmed), leaving quiz_slots with
        // no maxmark and sumgrades = 0  →  "cannot start: no gradeable questions".
        // ----------------------------------------------------------------
        $quiz->cmid = $cm->id;

        // Reload the quiz record from DB so the object reflects the actual
        // persisted state (e.g. sumgrades, grade), then re-attach cmid.
        $quiz = $DB->get_record('quiz', ['id' => $quiz->id], '*', MUST_EXIST);
        $quiz->cmid = $cm->id;

        // ----------------------------------------------------------------
        // 3. Get or create default question category for this course
        // ----------------------------------------------------------------
        $category = $DB->get_record_sql(
            "SELECT * FROM {question_categories} WHERE contextid = ? ORDER BY parent ASC, id ASC LIMIT 1",
            [$course_context->id]
        );
        if (!$category) {
            $category              = new \stdClass();
            $category->name        = 'Preguntas de ' . $course->fullname;
            $category->contextid   = $course_context->id;
            $category->info        = '';
            $category->infoformat  = FORMAT_HTML;
            $category->sortorder   = 999;
            $category->parent      = 0;
            $category->stamp       = time() . '+' . make_unique_id_code();
            $category->id = $DB->insert_record('question_categories', $category);
        }

        // ----------------------------------------------------------------
        // 4. Create questions and add them to the quiz
        // ----------------------------------------------------------------
        $quiz_context = \context_module::instance($cm->id);
        $has_question_refs = $DB->get_manager()->table_exists('question_references');

        // Explicitly create the default quiz section for Moodle 4.x +
        if ($has_question_refs) {
            $hqs = $DB->get_manager()->table_exists('quiz_sections');
            if ($hqs) {
                $section = new \stdClass();
                $section->quizid = $quiz->id;
                $section->firstslot = 1;
                $section->heading = '';
                $section->shufflequestions = 0;
                $DB->insert_record('quiz_sections', $section);
            }
        }

        foreach ($questions as $idx => $q_data) {
            $slot_num = $idx + 1;

            // Create the question record in the question bank
            $qid = self::create_question_for_bank(
                $q_data, $category->id, $slot_num
            );

            if ($has_question_refs) {
                // Completely bypass Moodle's native quiz_add_quiz_question which silently
                // fails in bulk custom injection (e.g., deduplication/cache false-positives).
                
                // 4a. quiz_slots
                // For AI generated quizzes (up to 15 questions), it is cleaner
                // to bunch them on a single page (page=1) rather than a page per slot.
                $slot = new \stdClass();
                $slot->quizid = $quiz->id;
                $slot->slot = $slot_num;
                $slot->page = 1; 
                $slot->displaynumber = '';
                $slot->requireprevious = 0;
                $slot->maxmark = isset($q_data['points']) ? (float)$q_data['points'] : 1.0;
                $slot_id = $DB->insert_record('quiz_slots', $slot);

                // 4b. question_references wiring
                $qv = $DB->get_record('question_versions', ['questionid' => $qid]);
                if ($qv) {
                    $qref = new \stdClass();
                    $qref->usingcontextid     = $quiz_context->id;
                    $qref->component          = 'mod_quiz';
                    $qref->questionarea       = 'slot';
                    $qref->itemid             = $slot_id;
                    $qref->questionbankentryid= $qv->questionbankentryid;
                    $qref->version            = null; // always latest
                    $DB->insert_record('question_references', $qref);
                }
            } else {
                // Fallback for Moodle 3.x
                $maxmark = isset($q_data['points']) ? (float)$q_data['points'] : 1.0;
                quiz_add_quiz_question($qid, $quiz, 0, $maxmark);
            }
        }

        // Recalculate sumgrades (sum of maxmark from quiz_slots)
        if (function_exists('quiz_update_sumgrades')) {
            quiz_update_sumgrades($quiz);
        }

        // Verify sumgrades was updated; if still 0 with questions, force-fix.
        $db_sumgrades = $DB->get_field('quiz', 'sumgrades', ['id' => $quiz->id]);
        if ($db_sumgrades == 0 && count($questions) > 0) {
            $expected = 0.0;
            foreach ($questions as $q) {
                $expected += isset($q['points']) ? (float)$q['points'] : 1.0;
            }
            $DB->set_field('quiz', 'sumgrades', $expected, ['id' => $quiz->id]);
            if ($max_grade === null) {
                $DB->set_field('quiz', 'grade', $expected, ['id' => $quiz->id]);
            }
            error_log('[RubricAI] Force-fixed sumgrades=' . $expected . ' for quiz id=' . $quiz->id);
        }

        // Force course cache rebuild
        rebuild_course_cache($courseid, true);
        get_fast_modinfo($courseid, 0, true);

        return ['coursemodule' => $cm->id];
    }

    // ------------------------------------------------------------------
    // Private: question creation helpers
    // ------------------------------------------------------------------

    /**
     * Create a single question in the question bank.
     * Returns the question ID. Moodle's quiz_add_quiz_question() handles
     * all quiz_slots/question_references/question_versions wiring.
     */
    private static function create_question_for_bank(
        array $q_data,
        int $category_id,
        int $slot_num
    ): int {
        global $DB, $USER;

        // --- Core question record ---
        $q                         = new \stdClass();
        $q->name                   = 'Pregunta ' . $slot_num . ': ' . substr($q_data['text'], 0, 50) . '...';
        $q->questiontext           = $q_data['text'];
        $q->questiontextformat     = FORMAT_HTML;
        $q->generalfeedback        = '';
        $q->generalfeedbackformat  = FORMAT_HTML;
        $q->defaultmark            = isset($q_data['points']) ? (float)$q_data['points'] : 1.0;
        $q->penalty                = ($q_data['type'] === 'essay') ? 0.0 : 0.3333333;
        $q->qtype                  = $q_data['type'];
        $q->length                 = ($q_data['type'] === 'description') ? 0 : 1;
        $q->stamp                  = make_unique_id_code();
        $q->category               = $category_id;
        $q->parent                 = 0;
        $q->hidden                 = 0;
        $q->timecreated            = time();
        $q->timemodified           = time();
        $q->createdby              = $USER->id;
        $q->modifiedby             = $USER->id;
        $q->version                = make_unique_id_code();
        $q->id = $DB->insert_record('question', $q);

        // --- Moodle 4.x: question_bank_entries + question_versions ---
        if ($DB->get_manager()->table_exists('question_bank_entries')) {
            $qbe                       = new \stdClass();
            $qbe->questioncategoryid   = $category_id;
            $qbe->idnumber             = null;
            $qbe->ownerid              = $USER->id;
            $qbe_id = $DB->insert_record('question_bank_entries', $qbe);

            $qv                       = new \stdClass();
            $qv->questionbankentryid  = $qbe_id;
            $qv->version              = 1;
            $qv->questionid           = $q->id;
            $qv->status               = 'ready';
            $DB->insert_record('question_versions', $qv);
        }

        // --- Type-specific options ---
        switch ($q_data['type']) {
            case 'multichoice':
                self::create_multichoice_data($q->id, $q_data);
                break;
            case 'truefalse':
                self::create_truefalse_data($q->id, $q_data);
                break;
            case 'match':
                self::create_match_data($q->id, $q_data);
                break;
            case 'shortanswer':
                self::create_shortanswer_data($q->id, $q_data);
                break;
            case 'numerical':
                self::create_numerical_data($q->id, $q_data);
                break;
            case 'gapselect':
                self::create_gapselect_data($q->id, $q_data);
                break;
            case 'multianswer':
                // Cloze questions only need the formatted text in questiontext.
                break;
            case 'essay':
                self::create_essay_data($q->id);
                break;
        }

        return $q->id;
    }

    /** Create answers + options for a multichoice question. */
    private static function create_multichoice_data(int $qid, array $q_data): void {
        global $DB;

        $correct_index = $q_data['correct'] ?? 0;
        foreach ($q_data['options'] as $i => $option_text) {
            $ans                  = new \stdClass();
            $ans->question        = $qid;
            $ans->answer          = $option_text;
            $ans->answerformat    = FORMAT_HTML;
            $ans->fraction        = ($i === $correct_index) ? 1.0 : 0.0;
            $ans->feedback        = '';
            $ans->feedbackformat  = FORMAT_HTML;
            $DB->insert_record('question_answers', $ans);
        }

        $opts                              = new \stdClass();
        $opts->questionid                  = $qid;
        $opts->layout                      = 0;
        $opts->single                      = 1; // single correct answer
        $opts->shuffleanswers              = 1;
        $opts->correctfeedback             = 'Correcto.';
        $opts->correctfeedbackformat       = FORMAT_HTML;
        $opts->partiallycorrectfeedback    = '';
        $opts->partiallycorrectfeedbackformat = FORMAT_HTML;
        $opts->incorrectfeedback           = 'Incorrecto.';
        $opts->incorrectfeedbackformat     = FORMAT_HTML;
        $opts->answernumbering             = 'abc';
        $opts->showstandardinstruction     = 1;
        $DB->insert_record('qtype_multichoice_options', $opts);
    }

    /** Create answers + options for a true/false question. */
    private static function create_truefalse_data(int $qid, array $q_data): void {
        global $DB;

        $correct = $q_data['correct'] ?? true;

        $true_ans               = new \stdClass();
        $true_ans->question     = $qid;
        $true_ans->answer       = 'True';
        $true_ans->answerformat = FORMAT_MOODLE;
        $true_ans->fraction     = $correct ? 1.0 : 0.0;
        $true_ans->feedback     = '';
        $true_ans->feedbackformat = FORMAT_HTML;
        $true_id = $DB->insert_record('question_answers', $true_ans);

        $false_ans               = new \stdClass();
        $false_ans->question     = $qid;
        $false_ans->answer       = 'False';
        $false_ans->answerformat = FORMAT_MOODLE;
        $false_ans->fraction     = $correct ? 0.0 : 1.0;
        $false_ans->feedback     = '';
        $false_ans->feedbackformat = FORMAT_HTML;
        $false_id = $DB->insert_record('question_answers', $false_ans);

        $opts               = new \stdClass();
        $opts->question     = $qid;
        $opts->trueanswer   = $true_id;
        $opts->falseanswer  = $false_id;
        $DB->insert_record('question_truefalse', $opts);
    }

    /** Create options for an essay question. */
    private static function create_essay_data(int $qid): void {
        global $DB;

        $opts                          = new \stdClass();
        $opts->questionid              = $qid;
        $opts->responseformat          = 'editor';
        $opts->responserequired        = 1;
        $opts->responsefieldlines      = 15;
        $opts->minwordlimit            = null;
        $opts->maxwordlimit            = null;
        $opts->attachments             = 0;
        $opts->attachmentsrequired     = 0;
        $opts->graderinfo              = '';
        $opts->graderinfoformat        = FORMAT_HTML;
        $opts->responsetemplate        = '';
        $opts->responsetemplateformat  = FORMAT_HTML;
        $opts->maxbytes                = 0;
        $DB->insert_record('qtype_essay_options', $opts);
    }

    /** Create subquestions and options for a matching question. */
    private static function create_match_data(int $qid, array $q_data): void {
        global $DB;

        foreach (($q_data['pairs'] ?? []) as $pair) {
            $sub = new \stdClass();
            $sub->questionid = $qid;
            $sub->questiontext = $pair['premise'];
            $sub->questiontextformat = FORMAT_HTML;
            $sub->answertext = $pair['answer'];
            $DB->insert_record('qtype_match_subquestions', $sub);
        }

        $opts                              = new \stdClass();
        $opts->questionid                  = $qid;
        $opts->shuffleanswers              = 1;
        $opts->correctfeedback             = 'Correcto.';
        $opts->correctfeedbackformat       = FORMAT_HTML;
        $opts->partiallycorrectfeedback    = '';
        $opts->partiallycorrectfeedbackformat = FORMAT_HTML;
        $opts->incorrectfeedback           = 'Incorrecto.';
        $opts->incorrectfeedbackformat     = FORMAT_HTML;
        $DB->insert_record('qtype_match_options', $opts);
    }

    /** Create answer and options for a shortanswer question. */
    private static function create_shortanswer_data(int $qid, array $q_data): void {
        global $DB;

        $ans                  = new \stdClass();
        $ans->question        = $qid;
        $ans->answer          = $q_data['correct'] ?? '';
        $ans->answerformat    = FORMAT_PLAIN;
        $ans->fraction        = 1.0;
        $ans->feedback        = 'Correcto.';
        $ans->feedbackformat  = FORMAT_HTML;
        $DB->insert_record('question_answers', $ans);

        $opts               = new \stdClass();
        $opts->questionid   = $qid;
        $opts->usecase      = 0; // Case insensitive
        $DB->insert_record('qtype_shortanswer_options', $opts);
    }

    /** Create answer and options for a numerical question. */
    private static function create_numerical_data(int $qid, array $q_data): void {
        global $DB;

        $ans                  = new \stdClass();
        $ans->question        = $qid;
        $ans->answer          = (string)($q_data['correct'] ?? '0');
        $ans->answerformat    = FORMAT_PLAIN;
        $ans->fraction        = 1.0;
        $ans->feedback        = 'Correcto.';
        $ans->feedbackformat  = FORMAT_HTML;
        $ans_id = $DB->insert_record('question_answers', $ans);

        // Numerical specific version of the answer
        $num = new \stdClass();
        $num->answer   = $ans_id;
        $num->tolerance = '0.01'; // Default tolerance
        $DB->insert_record('question_numerical', $num);

        $opts = new \stdClass();
        $opts->questionid = $qid;
        $opts->showunits = 0;
        $opts->unitgradingtype = 0;
        $opts->unitpenalty = 0.1;
        $opts->unitsleft = 0;
        $opts->instructions = '';
        $opts->instructionsformat = FORMAT_HTML;
        $DB->insert_record('qtype_numerical_options', $opts);
    }

    /** Create options for a gapselect (select missing words) question. */
    private static function create_gapselect_data(int $qid, array $q_data): void {
        global $DB;

        // Choices go to question_answers, grouped by 'feedback' field (used as group id)
        if (!empty($q_data['options'])) {
            foreach ($q_data['options'] as $choice) {
                $ans                  = new \stdClass();
                $ans->question        = $qid;
                $ans->answer          = $choice;
                $ans->answerformat    = FORMAT_PLAIN;
                $ans->fraction        = 0.0;
                $ans->feedback        = '1'; // Group 1
                $ans->feedbackformat  = FORMAT_PLAIN;
                $DB->insert_record('question_answers', $ans);
            }
        }

        $opts                              = new \stdClass();
        $opts->questionid                  = $qid;
        $opts->shuffleanswers              = 1;
        $opts->correctfeedback             = 'Correcto.';
        $opts->correctfeedbackformat       = FORMAT_HTML;
        $opts->partiallycorrectfeedback    = '';
        $opts->partiallycorrectfeedbackformat = FORMAT_HTML;
        $opts->incorrectfeedback           = 'Incorrecto.';
        $opts->incorrectfeedbackformat     = FORMAT_HTML;
        $DB->insert_record('qtype_gapselect', $opts);
    }

    /**
     * Create a new Moodle Assign activity programmatically
     * 
     * @param int $courseid
     * @param string $name
     * @param string $description
     * @param int $section_num  Section number (0 = General). Defaults to first non-zero section.
     * @return object The created course module info
     */
    public static function create_assign_activity($courseid, $name, $description, $section_num = -1) {
        global $CFG, $DB;
        require_once($CFG->dirroot . '/course/lib.php');
        
        $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $module = $DB->get_record('modules', ['name' => 'assign'], '*', MUST_EXIST);
        
        // Find or create a valid section
        $modinfo = get_fast_modinfo($course);
        $sections = $modinfo->get_section_info_all();
        $sectionid = 0;
        $sectionnum = 0;

        if ($section_num >= 0) {
            // Use the requested section
            foreach ($sections as $s) {
                if ((int)$s->section === $section_num) {
                    $sectionid = $s->id;
                    $sectionnum = $s->section;
                    break;
                }
            }
        }

        // Fallback: use first non-zero section
        if (!$sectionid) {
            foreach ($sections as $s) {
                if ($s->section > 0) {
                    $sectionid = $s->id;
                    $sectionnum = $s->section;
                    break;
                }
            }
        }
        if (!$sectionid) {
            foreach ($sections as $s) {
                if ((int)$s->section === 0) {
                    $sectionid = $s->id;
                    $sectionnum = $s->section;
                    break;
                }
            }
        }
        
        // Convert Markdown-like content to HTML for better display
        $html_description = format_text($description, FORMAT_MARKDOWN);

        // 1. Create assignment instance
        $assign = new \stdClass();
        $assign->course = $courseid;
        $assign->name = $name;
        $assign->intro = $html_description;
        $assign->introformat = FORMAT_HTML;
        $assign->grade = 100;
        $assign->submissiondrafts = 0;
        $assign->requiresubmissionstatement = 0;
        $assign->sendnotifications = 0;
        $assign->sendlatenotifications = 0;
        $assign->sendstudentnotifications = 1;
        $assign->teamsubmission = 0;
        $assign->requireallteammemberssubmit = 0;
        $assign->blindmarking = 0;
        $assign->markingworkflow = 0;
        $assign->markingallocation = 0;
        $assign->timemodified = time();
        $assign->id = $DB->insert_record('assign', $assign);

        // 2. Enable online text submission by default
        $plugin = new \stdClass();
        $plugin->assignment = $assign->id;
        $plugin->plugin = 'onlinetext';
        $plugin->subtype = 'assignsubmission';
        $plugin->name = 'enabled';
        $plugin->value = '1';
        $DB->insert_record('assign_plugin_config', $plugin);

        // 3. Enable file submission with proper limit configurations
        $maxbytes = isset($course->maxbytes) ? (int)$course->maxbytes : 0;
        if ($maxbytes <= 0) {
            global $CFG;
            $maxbytes = !empty($CFG->maxbytes) ? (int)$CFG->maxbytes : 52428800; // 50MB fallback
        }

        $plugin_file_enabled = new \stdClass();
        $plugin_file_enabled->assignment = $assign->id;
        $plugin_file_enabled->plugin = 'file';
        $plugin_file_enabled->subtype = 'assignsubmission';
        $plugin_file_enabled->name = 'enabled';
        $plugin_file_enabled->value = '1';
        $DB->insert_record('assign_plugin_config', $plugin_file_enabled);

        $plugin_file_max = new \stdClass();
        $plugin_file_max->assignment = $assign->id;
        $plugin_file_max->plugin = 'file';
        $plugin_file_max->subtype = 'assignsubmission';
        $plugin_file_max->name = 'maxfilesubmissions';
        $plugin_file_max->value = '5'; // Allow up to 5 files
        $DB->insert_record('assign_plugin_config', $plugin_file_max);

        $plugin_file_size = new \stdClass();
        $plugin_file_size->assignment = $assign->id;
        $plugin_file_size->plugin = 'file';
        $plugin_file_size->subtype = 'assignsubmission';
        $plugin_file_size->name = 'maxsubmissionsizebytes';
        $plugin_file_size->value = (string)$maxbytes;
        $DB->insert_record('assign_plugin_config', $plugin_file_size);

        $plugin_file_types = new \stdClass();
        $plugin_file_types->assignment = $assign->id;
        $plugin_file_types->plugin = 'file';
        $plugin_file_types->subtype = 'assignsubmission';
        $plugin_file_types->name = 'filetypeslist';
        $plugin_file_types->value = '*'; // Allow all file types
        $DB->insert_record('assign_plugin_config', $plugin_file_types);
        
        // 4. Add course module
        $cm = new \stdClass();
        $cm->course = $courseid;
        $cm->module = $module->id;
        $cm->instance = $assign->id;
        $cm->section = $sectionid;
        $cm->id = add_course_module($cm);
        
        // 5. Add cm to section
        course_add_cm_to_section($courseid, $cm->id, $sectionnum);
        
        // 6. Rebuild cache
        rebuild_course_cache($courseid, true);
        
        return (object)['coursemodule' => $cm->id];
    }

    /**
     * Create a new Moodle Forum activity programmatically.
     * Used for debate and oral evaluation instruments.
     * 
     * @param int $courseid
     * @param string $name
     * @param string $description
     * @param int $section_num  Section number (0 = General). Defaults to first non-zero section.
     * @return object The created course module info
     */
    public static function create_forum_activity($courseid, $name, $description, $section_num = -1) {
        global $CFG, $DB;
        require_once($CFG->dirroot . '/course/lib.php');
        require_once($CFG->dirroot . '/mod/forum/lib.php');
        
        $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $module = $DB->get_record('modules', ['name' => 'forum'], '*', MUST_EXIST);
        
        // Find the requested section
        $modinfo = get_fast_modinfo($course);
        $sections = $modinfo->get_section_info_all();
        $sectionid = 0;
        $sectionnum = 0;

        if ($section_num >= 0) {
            foreach ($sections as $s) {
                if ((int)$s->section === $section_num) {
                    $sectionid = $s->id;
                    $sectionnum = $s->section;
                    break;
                }
            }
        }

        // Fallback: use first non-zero section
        if (!$sectionid) {
            foreach ($sections as $s) {
                if ($s->section > 0) {
                    $sectionid = $s->id;
                    $sectionnum = $s->section;
                    break;
                }
            }
        }
        if (!$sectionid) {
            foreach ($sections as $s) {
                if ((int)$s->section === 0) {
                    $sectionid = $s->id;
                    $sectionnum = $s->section;
                    break;
                }
            }
        }

        // Convert Markdown-like content to HTML
        $html_description = format_text($description, FORMAT_MARKDOWN);

        // 1. Create forum instance
        $forum = new \stdClass();
        $forum->course = $courseid;
        $forum->name = $name;
        $forum->intro = $html_description;
        $forum->introformat = FORMAT_HTML;
        $forum->type = 'general';   // general discussion forum
        $forum->assessed = 0;       // no rating by default
        $forum->scale = 100;
        $forum->forcesubscribe = 0; // optional subscription
        $forum->trackingtype = 1;   // optional tracking
        $forum->maxbytes = 0;
        $forum->maxattachments = 9;
        $forum->timemodified = time();
        $forum->id = $DB->insert_record('forum', $forum);

        // 2. Add course module
        $cm = new \stdClass();
        $cm->course = $courseid;
        $cm->module = $module->id;
        $cm->instance = $forum->id;
        $cm->section = $sectionid;
        $cm->id = add_course_module($cm);

        // 3. Add cm to section
        course_add_cm_to_section($courseid, $cm->id, $sectionnum);

        // 4. Rebuild cache
        rebuild_course_cache($courseid, true);

        return (object)['coursemodule' => $cm->id];
    }

    /**
     * Extracts ALL resources and activities in the course (with their settings and contents)
     * for evaluation against the rubric by the python microservice.
     *
     * @param int $courseid
     * @return array
     */
    public static function get_course_full_evaluation_payload(int $courseid): array {
        global $DB;
        
        $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $modinfo = get_fast_modinfo($course);
        
        $payload = [
            'id' => $courseid,
            'fullname' => $course->fullname,
            'shortname' => $course->shortname,
            'summary' => self::clean_html($course->summary),
            'sections' => []
        ];
        
        foreach ($modinfo->get_section_info_all() as $section) {
            if (!$section->uservisible) continue;
            
            $sectiondata = [
                'num' => (int)$section->section,
                'name' => self::get_section_name_clean($course, $section),
                'summary' => self::clean_html($section->summary),
                'activities' => []
            ];
            
            if (!empty($modinfo->sections[$section->section])) {
                foreach ($modinfo->sections[$section->section] as $cmid) {
                    $cm = $modinfo->get_cm($cmid);
                    if (!$cm->uservisible) continue;
                    if ($cm->modname === 'label') {
                        $record = $DB->get_record('label', ['id' => $cm->instance]);
                        if ($record) {
                            $act = [
                                'id' => (int)$cm->id,
                                'name' => 'Etiqueta',
                                'type' => $cm->modname,
                                'description' => $record->intro,
                                'settings' => []
                            ];
                            $sectiondata['activities'][] = $act;
                        }
                        continue;
                    }
                    
                    $act = [
                        'id' => (int)$cm->id,
                        'name' => $cm->name,
                        'type' => $cm->modname,
                        'description' => '',
                        'settings' => []
                    ];
                    
                    // Fetch details depending on module type
                    if ($cm->modname === 'assign') {
                        $record = $DB->get_record('assign', ['id' => $cm->instance]);
                        if ($record) {
                            $desc = preg_replace('/\s+/', ' ', self::clean_html($record->intro));
                            $act['description'] = strlen($desc) > 1000 ? substr($desc, 0, 1000) . '...' : $desc;
                            $act['settings'] = [
                                'duedate' => (int)$record->duedate,
                                'allowsubmissionsfromdate' => (int)$record->allowsubmissionsfromdate,
                                'grade' => (float)$record->grade,
                                'teamsubmission' => (int)$record->teamsubmission,
                            ];
                        }
                    } else if ($cm->modname === 'forum') {
                        $record = $DB->get_record('forum', ['id' => $cm->instance]);
                        if ($record) {
                            $desc = preg_replace('/\s+/', ' ', self::clean_html($record->intro));
                            $act['description'] = strlen($desc) > 1000 ? substr($desc, 0, 1000) . '...' : $desc;
                            $act['settings'] = [
                                'type' => $record->type,
                                'assessed' => (int)$record->assessed,
                                'scale' => (float)$record->scale,
                            ];
                        }
                    } else if ($cm->modname === 'quiz') {
                        $record = $DB->get_record('quiz', ['id' => $cm->instance]);
                        if ($record) {
                            $desc = preg_replace('/\s+/', ' ', self::clean_html($record->intro));
                            $act['description'] = strlen($desc) > 1000 ? substr($desc, 0, 1000) . '...' : $desc;
                            $act['settings'] = [
                                'timeopen' => (int)$record->timeopen,
                                'timeclose' => (int)$record->timeclose,
                                'timelimit' => (int)$record->timelimit,
                                'grade' => (float)$record->grade,
                                'sumgrades' => (float)$record->sumgrades,
                            ];
                            
                            // Query questions inside this quiz
                            $questions = [];
                            $has_question_refs = $DB->get_manager()->table_exists('question_references');
                            if ($has_question_refs) {
                                $sql = "SELECT q.id, q.name, q.questiontext, q.qtype, q.defaultmark
                                        FROM {quiz_slots} slot
                                        JOIN {question_references} qref ON qref.itemid = slot.id
                                        JOIN {question_bank_entries} qbe ON qbe.id = qref.questionbankentryid
                                        JOIN {question_versions} qv ON qv.questionbankentryid = qbe.id
                                        JOIN {question} q ON q.id = qv.questionid
                                        WHERE slot.quizid = ? AND qv.status = 'ready'";
                                $qrecords = $DB->get_records_sql($sql, [$record->id]);
                            } else {
                                $sql = "SELECT q.id, q.name, q.questiontext, q.qtype, q.defaultmark
                                        FROM {quiz_slots} slot
                                        JOIN {question} q ON q.id = slot.questionid
                                        WHERE slot.quizid = ?";
                                $qrecords = $DB->get_records_sql($sql, [$record->id]);
                            }
                            if ($qrecords) {
                                foreach ($qrecords as $qr) {
                                    $qtext = preg_replace('/\s+/', ' ', self::clean_html($qr->questiontext));
                                    $questions[] = [
                                        'id' => (int)$qr->id,
                                        'name' => $qr->name,
                                        'text' => strlen($qtext) > 500 ? substr($qtext, 0, 500) . '...' : $qtext,
                                        'type' => $qr->qtype,
                                        'points' => (float)$qr->defaultmark
                                    ];
                                }
                            }
                            $act['questions'] = $questions;
                        }
                    } else if (in_array($cm->modname, ['resource', 'page', 'url', 'book', 'folder'])) {
                        // For resource/resource modules
                        $desc = $cm->content;
                        if ($cm->modname === 'page') {
                            $record = $DB->get_record('page', ['id' => $cm->instance]);
                            if ($record) {
                                $desc .= "\n" . $record->content;
                            }
                        } else if ($cm->modname === 'url') {
                            $record = $DB->get_record('url', ['id' => $cm->instance]);
                            if ($record) {
                                $act['settings']['externalurl'] = $record->externalurl;
                            }
                        }
                        $cleaned_desc = preg_replace('/\s+/', ' ', self::clean_html($desc));
                        $act['description'] = strlen($cleaned_desc) > 1000 ? substr($cleaned_desc, 0, 1000) . '...' : $cleaned_desc;
                    }
                    
                    $sectiondata['activities'][] = $act;
                }
            }
            $payload['sections'][] = $sectiondata;
        }
        
        return $payload;
    }

    /**
     * Recursively delete the sync directory for a course.
     *
     * @param int $courseid
     */
    public static function delete_sync_dir($courseid) {
        global $CFG;
        $base_sync_dir = $CFG->dataroot . '/rubricai_sync/course_' . $courseid;
        if (file_exists($base_sync_dir)) {
            self::rrmdir($base_sync_dir);
        }
    }

    /**
     * Internal recursive directory removal helper.
     */
    private static function rrmdir($dir) {
        if (!is_dir($dir)) return;
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item == '.' || $item == '..') continue;
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path)) {
                self::rrmdir($path);
            } else {
                unlink($path);
            }
        }
        rmdir($dir);
    }

    /**
     * Get a cleaned section name, falling back to a default if empty/spaces.
     *
     * @param \stdClass $course
     * @param \section_info $section
     * @return string
     */
    public static function get_section_name_clean($course, $section): string {
        $name = trim(get_section_name($course, $section));
        if ($name === '') {
            if ($section->section == 0) {
                // Section 0 is always General/General Info
                $name = get_string('general', 'moodle');
                if (empty($name) || $name === 'general') {
                    $name = 'General';
                }
            } else {
                // Other sections, e.g. Tema 1, Semana 1, etc.
                try {
                    $name = get_string('sectionname', 'format_' . $course->format);
                } catch (\Exception $e) {
                    $name = 'Sección';
                }
                if (empty($name) || $name === 'sectionname') {
                    $name = 'Sección';
                }
                $name .= ' ' . $section->section;
            }
        }
        return $name;
    }

    /**
     * Get the text content representing a Moodle activity (assignment, quiz, forum, page, book, etc.)
     *
     * @param object $cm
     * @return string
     */
    public static function get_activity_text($cm): string {
        global $DB;
        $text = "Actividad: " . $cm->name . "\nTipo: " . $cm->modname . "\n\n";

        try {
            if ($cm->modname === 'assign') {
                $record = $DB->get_record('assign', ['id' => $cm->instance]);
                if ($record) {
                    $text .= "Instrucciones de la tarea:\n" . self::clean_html($record->intro);
                }
            } else if ($cm->modname === 'forum') {
                $record = $DB->get_record('forum', ['id' => $cm->instance]);
                if ($record) {
                    $text .= "Descripción del foro:\n" . self::clean_html($record->intro);
                }
            } else if ($cm->modname === 'page') {
                $record = $DB->get_record('page', ['id' => $cm->instance]);
                if ($record) {
                    $text .= "Descripción:\n" . self::clean_html($record->intro) . "\n\nContenido de la página:\n" . self::clean_html($record->content);
                }
            } else if ($cm->modname === 'url') {
                $record = $DB->get_record('url', ['id' => $cm->instance]);
                if ($record) {
                    $text .= "Descripción:\n" . self::clean_html($record->intro) . "\nURL: " . $record->externalurl;
                }
            } else if ($cm->modname === 'book') {
                $record = $DB->get_record('book', ['id' => $cm->instance]);
                if ($record) {
                    $text .= "Libro: " . $record->name . "\n" . self::clean_html($record->intro) . "\n\nCapítulos:\n";
                    $chapters = $DB->get_records('book_chapters', ['bookid' => $record->id], 'pagenum');
                    if ($chapters) {
                        foreach ($chapters as $ch) {
                            $text .= "\nTítulo: " . $ch->title . "\n" . self::clean_html($ch->content);
                        }
                    }
                }
            } else if ($cm->modname === 'quiz') {
                $record = $DB->get_record('quiz', ['id' => $cm->instance]);
                if ($record) {
                    $text .= "Descripción del cuestionario:\n" . self::clean_html($record->intro) . "\n\nPreguntas:\n";
                    $has_question_refs = $DB->get_manager()->table_exists('question_references');
                    if ($has_question_refs) {
                        $sql = "SELECT q.id, q.name, q.questiontext
                                FROM {quiz_slots} slot
                                JOIN {question_references} qref ON qref.itemid = slot.id
                                JOIN {question_bank_entries} qbe ON qbe.id = qref.questionbankentryid
                                JOIN {question_versions} qv ON qv.questionbankentryid = qbe.id
                                JOIN {question} q ON q.id = qv.questionid
                                WHERE slot.quizid = ? AND qv.status = 'ready'";
                        $qrecords = $DB->get_records_sql($sql, [$record->id]);
                    } else {
                        $sql = "SELECT q.id, q.name, q.questiontext
                                FROM {quiz_slots} slot
                                JOIN {question} q ON q.id = slot.questionid
                                WHERE slot.quizid = ?";
                        $qrecords = $DB->get_records_sql($sql, [$record->id]);
                    }
                    if ($qrecords) {
                        foreach ($qrecords as $qr) {
                            $text .= "- " . $qr->name . ": " . self::clean_html($qr->questiontext) . "\n";
                        }
                    }
                }
            } else if ($cm->modname === 'label') {
                $record = $DB->get_record('label', ['id' => $cm->instance]);
                if ($record) {
                    $text .= "Contenido de la etiqueta:\n" . self::clean_html($record->intro);
                }
            } else {
                if ($cm->content) {
                     $text .= "Detalles:\n" . self::clean_html($cm->content);
                }
            }
        } catch (\Exception $e) {
            $text .= "\nError al obtener detalles: " . $e->getMessage();
        }

        return trim($text);
    }

    /**
     * Cleans HTML content by removing style and script tags and their contents,
     * stripping other HTML tags, and decoding entities.
     *
     * @param string $html
     * @return string
     */
    public static function clean_html(?string $html): string {
        if (empty($html)) {
            return '';
        }
        // Remove style blocks and their contents
        $html = preg_replace('/<style\b[^>]*>(.*?)<\/style>/is', '', $html);
        // Remove script blocks and their contents
        $html = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $html);
        // Now strip tags
        $text = strip_tags($html);
        // Decode HTML entities
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return trim($text);
    }
}
